import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Desktop (Swing) interface of the Bank Management System. */
public class BankApp extends JPanel {

    static final Color NAVY = new Color(0x1F, 0x3A, 0x5F);
    static final Color TEAL = new Color(0x2A, 0x9D, 0x8F);
    static final Color LIGHT = new Color(0xEA, 0xF1, 0xF8);
    static final Color GREEN = new Color(0x1B, 0x7F, 0x4B);
    static final Color RED = new Color(0xC0, 0x39, 0x2B);

    final Bank bank = new Bank("BTech National Bank");
    final JTabbedPane tabs = new JTabbedPane();

    // Dashboard
    final JLabel lblAccounts = valueLabel(), lblSavings = valueLabel(),
            lblCurrent = valueLabel(), lblTotal = valueLabel();
    final DefaultTableModel accountModel =
            model("Account No.", "Account Holder", "Type", "Balance (Rs.)");
    final JLabel emptyHint = new JLabel(
            "No accounts yet. Create one in the Operations tab or import a CSV file.", SwingConstants.CENTER);

    // Operations
    final JComboBox<String> typeBox = new JComboBox<String>(new String[]{"Savings", "Current"});
    final JTextField holderField = new JTextField(18);
    final JTextField numberField = new JTextField(12);
    final JTextField amountField = new JTextField(12);
    final JButton btnCreate = button("Create Account", TEAL);
    final JButton btnDeposit = button("Deposit", NAVY);
    final JButton btnWithdraw = button("Withdraw", NAVY);
    final JButton btnBalance = button("Check Balance", NAVY);
    final JTextArea messageArea = new JTextArea();

    // CSV import
    final JTextField csvPathField = new JTextField();
    final JButton btnChooseCsv = button("Choose CSV File...", TEAL);
    final DefaultTableModel csvModel = model("#", "Action", "Account", "Amount (Rs.)", "Status", "Details");
    final JLabel csvSummary = new JLabel("No file processed yet.");

    // Specification viewer
    final JTextField specPathField = new JTextField();
    final JButton btnLoadSpec = button("Load Specification CSV...", TEAL);
    final DefaultTableModel specModel = model("Load the specification file to view it here");
    JTable specTable;

    public BankApp() {
        setLayout(new BorderLayout());
        add(buildHeader(), BorderLayout.NORTH);

        tabs.setFont(new Font("SansSerif", Font.BOLD, 14));
        tabs.addTab("Dashboard", buildDashboard());
        tabs.addTab("Operations", buildOperations());
        tabs.addTab("CSV Import", buildCsvTab());
        tabs.addTab("Specification", buildSpecTab());
        add(tabs, BorderLayout.CENTER);

        setPreferredSize(new Dimension(1000, 700));
        refreshDashboard();
    }

    // ------------------------------------------------------------------ header
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout(16, 0));
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(10, 18, 10, 18));
        try {
            Image logo = ImageIO.read(new File("logo.png"));
            int h = 64, w = logo.getWidth(null) * h / logo.getHeight(null);
            header.add(new JLabel(new ImageIcon(logo.getScaledInstance(w, h, Image.SCALE_SMOOTH))),
                    BorderLayout.WEST);
        } catch (Exception ignored) {
            // the application also works without a logo file
        }
        JPanel text = new JPanel(new GridLayout(2, 1));
        text.setOpaque(false);
        JLabel title = new JLabel("Bank Management System");
        title.setFont(new Font("SansSerif", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel(bank.getBankName() + "  |  Second Year BTech Project  |  Sri Sri University");
        sub.setFont(new Font("SansSerif", Font.PLAIN, 13));
        sub.setForeground(new Color(0xBFD3E6));
        text.add(title);
        text.add(sub);
        header.add(text, BorderLayout.CENTER);
        return header;
    }

    // --------------------------------------------------------------- dashboard
    private JPanel buildDashboard() {
        JPanel page = new JPanel(new BorderLayout(0, 14));
        page.setBorder(new EmptyBorder(16, 18, 16, 18));

        JPanel cards = new JPanel(new GridLayout(1, 4, 14, 0));
        cards.add(card("Total Accounts", lblAccounts, NAVY));
        cards.add(card("Savings Accounts", lblSavings, TEAL));
        cards.add(card("Current Accounts", lblCurrent, new Color(0xE0, 0x9F, 0x1F)));
        cards.add(card("Total Balance", lblTotal, new Color(0x6A, 0x4C, 0x93)));
        page.add(cards, BorderLayout.NORTH);

        JTable table = styledTable(accountModel);
        JScrollPane scroll = scrollOf(table);
        emptyHint.setFont(new Font("SansSerif", Font.ITALIC, 14));
        emptyHint.setForeground(Color.GRAY);
        JPanel center = new JPanel(new BorderLayout());
        center.add(scroll, BorderLayout.CENTER);
        center.add(emptyHint, BorderLayout.SOUTH);
        center.setBorder(javax.swing.BorderFactory.createTitledBorder("All Accounts"));
        page.add(center, BorderLayout.CENTER);
        return page;
    }

    private JPanel card(String caption, JLabel value, Color color) {
        JPanel p = new JPanel(new GridLayout(2, 1));
        p.setBackground(Color.WHITE);
        p.setBorder(new javax.swing.border.CompoundBorder(new LineBorder(color, 2, true), new EmptyBorder(10, 14, 10, 14)));
        JLabel c = new JLabel(caption);
        c.setFont(new Font("SansSerif", Font.BOLD, 13));
        c.setForeground(Color.DARK_GRAY);
        value.setForeground(color);
        p.add(c);
        p.add(value);
        return p;
    }

    // -------------------------------------------------------------- operations
    private JPanel buildOperations() {
        JPanel page = new JPanel(new BorderLayout(0, 14));
        page.setBorder(new EmptyBorder(16, 18, 16, 18));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(javax.swing.BorderFactory.createTitledBorder("Account Details"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 10, 8, 10);
        g.anchor = GridBagConstraints.WEST;
        addRow(form, g, 0, "Account Type", typeBox, "Account Holder Name", holderField);
        addRow(form, g, 1, "Account Number", numberField, "Amount (Rs.)", amountField);
        page.add(form, BorderLayout.NORTH);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 6));
        buttons.add(btnCreate);
        buttons.add(btnDeposit);
        buttons.add(btnWithdraw);
        buttons.add(btnBalance);

        messageArea.setEditable(false);
        messageArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        messageArea.setMargin(new Insets(8, 10, 8, 10));
        JPanel log = new JPanel(new BorderLayout());
        log.setBorder(javax.swing.BorderFactory.createTitledBorder("Messages"));
        log.add(new JScrollPane(messageArea), BorderLayout.CENTER);

        JPanel lower = new JPanel(new BorderLayout(0, 8));
        lower.add(buttons, BorderLayout.NORTH);
        lower.add(log, BorderLayout.CENTER);
        page.add(lower, BorderLayout.CENTER);

        btnCreate.addActionListener(e -> doCreate());
        btnDeposit.addActionListener(e -> doDeposit());
        btnWithdraw.addActionListener(e -> doWithdraw());
        btnBalance.addActionListener(e -> doBalance());
        return page;
    }

    private void addRow(JPanel p, GridBagConstraints g, int row, String l1, JComponent c1, String l2, JComponent c2) {
        g.gridy = row;
        g.gridx = 0; p.add(new JLabel(l1), g);
        g.gridx = 1; p.add(c1, g);
        g.gridx = 2; p.add(new JLabel(l2), g);
        g.gridx = 3; p.add(c2, g);
    }

    void doCreate() {
        try {
            String holder = holderField.getText().trim();
            if (holder.isEmpty()) {
                throw new BankException("Please enter the account holder name.");
            }
            Account a = bank.createAccount((String) typeBox.getSelectedItem(), holder, readAmount());
            numberField.setText(a.getAccountNumber());
            say("SUCCESS  " + a.getAccountType() + " account " + a.getAccountNumber()
                    + " created for " + holder + ".");
        } catch (BankException ex) {
            say("REJECTED " + ex.getMessage());
        } catch (NumberFormatException ex) {
            say("REJECTED Please enter a valid amount.");
        }
        refreshDashboard();
    }

    void doDeposit() {
        try {
            double bal = bank.deposit(numberField.getText().trim(), readAmount());
            say("SUCCESS  Deposit done. New balance: " + money(bal));
        } catch (BankException ex) {
            say("REJECTED " + ex.getMessage());
        } catch (NumberFormatException ex) {
            say("REJECTED Please enter a valid amount.");
        }
        refreshDashboard();
    }

    void doWithdraw() {
        try {
            double bal = bank.withdraw(numberField.getText().trim(), readAmount());
            say("SUCCESS  Withdrawal done. New balance: " + money(bal));
        } catch (BankException ex) {
            say("REJECTED " + ex.getMessage());
        } catch (NumberFormatException ex) {
            say("REJECTED Please enter a valid amount.");
        }
        refreshDashboard();
    }

    void doBalance() {
        try {
            say("BALANCE  " + numberField.getText().trim() + " = "
                    + money(bank.checkBalance(numberField.getText().trim())));
        } catch (BankException ex) {
            say("REJECTED " + ex.getMessage());
        }
    }

    private double readAmount() {
        return Double.parseDouble(amountField.getText().trim());
    }

    private void say(String text) {
        messageArea.append(text + "\n");
    }

    // ------------------------------------------------------------- CSV import
    private JPanel buildCsvTab() {
        JPanel page = new JPanel(new BorderLayout(0, 12));
        page.setBorder(new EmptyBorder(16, 18, 16, 18));

        JPanel top = new JPanel(new BorderLayout(10, 6));
        JLabel info = new JLabel("<html>Choose a transactions file. Required columns: "
                + "<b>Action, AccountType, HolderName, AccountNumber, Amount</b> "
                + "(actions: CREATE, DEPOSIT, WITHDRAW, BALANCE)</html>");
        csvPathField.setEditable(false);
        csvPathField.setText("No file selected");
        top.add(info, BorderLayout.NORTH);
        top.add(csvPathField, BorderLayout.CENTER);
        top.add(btnChooseCsv, BorderLayout.EAST);
        page.add(top, BorderLayout.NORTH);

        JTable table = styledTable(csvModel);
        table.setRowHeight(23);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(2).setPreferredWidth(90);
        table.getColumnModel().getColumn(3).setPreferredWidth(110);
        table.getColumnModel().getColumn(4).setPreferredWidth(90);
        table.getColumnModel().getColumn(5).setPreferredWidth(420);
        table.getColumnModel().getColumn(4).setCellRenderer(new StatusRenderer());
        page.add(scrollOf(table), BorderLayout.CENTER);

        csvSummary.setFont(new Font("SansSerif", Font.BOLD, 14));
        csvSummary.setForeground(NAVY);
        page.add(csvSummary, BorderLayout.SOUTH);

        btnChooseCsv.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(".");
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                processCsv(chooser.getSelectedFile());
            }
        });
        return page;
    }

    void processCsv(File file) {
        csvPathField.setText(file.getAbsolutePath());
        csvModel.setRowCount(0);
        try {
            List<CsvProcessor.Result> results = CsvProcessor.process(file, bank);
            int ok = 0, bad = 0;
            for (CsvProcessor.Result r : results) {
                csvModel.addRow(new Object[]{r.row, r.action, r.account, r.amount, r.status, r.message});
                if ("Success".equals(r.status)) ok++; else bad++;
            }
            csvSummary.setForeground(NAVY);
            csvSummary.setText("Rows processed: " + results.size() + "   |   Successful: " + ok
                    + "   |   Rejected: " + bad + "   |   Total balance now: " + money(bank.getTotalBalance()));
        } catch (Exception ex) {
            csvSummary.setForeground(RED);
            csvSummary.setText("Could not read the file: " + ex.getMessage());
        }
        refreshDashboard();
    }

    // ------------------------------------------------------- specification tab
    private JPanel buildSpecTab() {
        JPanel page = new JPanel(new BorderLayout(0, 12));
        page.setBorder(new EmptyBorder(16, 18, 16, 18));
        JPanel top = new JPanel(new BorderLayout(10, 6));
        specPathField.setEditable(false);
        specPathField.setText("No file selected");
        top.add(new JLabel("View the project specification (features, OOP concepts and classes) stored as a CSV file."),
                BorderLayout.NORTH);
        top.add(specPathField, BorderLayout.CENTER);
        top.add(btnLoadSpec, BorderLayout.EAST);
        page.add(top, BorderLayout.NORTH);
        specTable = styledTable(specModel);
        page.add(scrollOf(specTable), BorderLayout.CENTER);

        btnLoadSpec.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(".");
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                loadSpec(chooser.getSelectedFile());
            }
        });
        return page;
    }

    void loadSpec(File file) {
        specPathField.setText(file.getAbsolutePath());
        try {
            List<String[]> rows = CsvProcessor.readAll(file);
            String[] head = rows.get(0);
            List<Integer> show = new ArrayList<Integer>();
            for (int i = 0; i < head.length; i++) {
                if (!head[i].equals("Attributes") && !head[i].equals("Methods")) show.add(i);
            }
            Object[] columns = new Object[show.size()];
            for (int i = 0; i < columns.length; i++) columns[i] = head[show.get(i)];
            specModel.setDataVector(new Object[0][0], columns);
            for (int r = 1; r < rows.size(); r++) {
                Object[] line = new Object[columns.length];
                for (int i = 0; i < columns.length; i++) line[i] = rows.get(r)[show.get(i)];
                specModel.addRow(line);
            }
            String[] names = {"Category", "ID", "Name", "Description", "OOP Concept Applied", "Related Classes"};
            int[] widths = {95, 45, 125, 360, 150, 205};
            for (int i = 0; i < columns.length; i++) {
                for (int k = 0; k < names.length; k++) {
                    if (names[k].equals(columns[i])) specTable.getColumnModel().getColumn(i).setPreferredWidth(widths[k]);
                }
            }
        } catch (Exception ex) {
            specPathField.setText("Could not read the file: " + ex.getMessage());
        }
    }

    // ----------------------------------------------------------------- helpers
    void refreshDashboard() {
        accountModel.setRowCount(0);
        int savings = 0, current = 0;
        for (Account a : bank.getAllAccounts()) {
            accountModel.addRow(new Object[]{a.getAccountNumber(), a.getHolderName(), a.getAccountType(),
                    String.format("%,.2f", a.getBalance())});
            if (a instanceof SavingsAccount) savings++; else current++;
        }
        lblAccounts.setText(String.valueOf(savings + current));
        lblSavings.setText(String.valueOf(savings));
        lblCurrent.setText(String.valueOf(current));
        lblTotal.setText(money(bank.getTotalBalance()));
        lblTotal.setFont(new Font("SansSerif", Font.BOLD, 20));
        emptyHint.setVisible(accountModel.getRowCount() == 0);
    }

    static JScrollPane scrollOf(JTable t) {
        JScrollPane sp = new JScrollPane(t);
        sp.setColumnHeaderView(t.getTableHeader());
        return sp;
    }

    static String money(double v) {
        return String.format("Rs. %,.2f", v);
    }

    static JLabel valueLabel() {
        JLabel l = new JLabel("0");
        l.setFont(new Font("SansSerif", Font.BOLD, 26));
        return l;
    }

    static JButton button(String text, Color color) {
        JButton b = new JButton(text);
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(9, 18, 9, 18));
        b.setOpaque(true);
        return b;
    }

    static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    static JTable styledTable(DefaultTableModel m) {
        JTable t = new JTable(m);
        t.setRowHeight(28);
        t.setFont(new Font("SansSerif", Font.PLAIN, 13));
        t.setShowGrid(true);
        t.setGridColor(new Color(0xD5DDE8));
        t.setFillsViewportHeight(true);
        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean s, boolean f, int r, int c) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(tb, v, s, f, r, c);
                l.setBackground(NAVY);
                l.setForeground(Color.WHITE);
                l.setFont(new Font("SansSerif", Font.BOLD, 13));
                l.setHorizontalAlignment(SwingConstants.CENTER);
                l.setBorder(new EmptyBorder(6, 6, 6, 6));
                return l;
            }
        });
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean s, boolean f, int r, int c) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(tb, v, s, f, r, c);
                l.setBackground(r % 2 == 0 ? Color.WHITE : LIGHT);
                l.setForeground(Color.BLACK);
                l.setBorder(new EmptyBorder(0, 8, 0, 8));
                return l;
            }
        });
        return t;
    }

    /** Colours the Status column green / red. */
    static class StatusRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable tb, Object v, boolean s, boolean f, int r, int c) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(tb, v, s, f, r, c);
            l.setBackground(r % 2 == 0 ? Color.WHITE : LIGHT);
            l.setForeground("Success".equals(v) ? GREEN : RED);
            l.setFont(new Font("SansSerif", Font.BOLD, 13));
            l.setHorizontalAlignment(SwingConstants.CENTER);
            return l;
        }
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            // fall back to the default look and feel
        }
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Bank Management System - Sri Sri University");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setContentPane(new BankApp());
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
