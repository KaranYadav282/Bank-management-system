import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/** Runs the designed test cases and writes the results to a CSV file. */
public class TestRunner {

    interface Check { String run() throws Exception; }

    static final List<String[]> rows = new ArrayList<String[]>();

    static void test(String id, String description, String expected, Check check) {
        String actual;
        try {
            actual = check.run();
        } catch (Exception e) {
            actual = e.getClass().getSimpleName();
        }
        rows.add(new String[]{id, description, expected, actual, expected.equals(actual) ? "Pass" : "Fail"});
    }

    public static void main(String[] args) throws Exception {
        final Bank bank = new Bank("Test Bank");
        final Account s = bank.createAccount("savings", "Test Savings", 5000);
        final Account c = bank.createAccount("current", "Test Current", 2000);

        test("T01", "Create savings account with Rs. 5,000", "5000.0",
                () -> String.valueOf(bank.checkBalance(s.getAccountNumber())));
        test("T02", "Deposit Rs. 1,500 into savings account", "6500.0",
                () -> String.valueOf(bank.deposit(s.getAccountNumber(), 1500)));
        test("T03", "Withdraw Rs. 2,000 from savings account", "4500.0",
                () -> String.valueOf(bank.withdraw(s.getAccountNumber(), 2000)));
        test("T04", "Withdraw below minimum balance (savings)", "InsufficientFundsException",
                () -> String.valueOf(bank.withdraw(s.getAccountNumber(), 4300)));
        test("T05", "Withdraw Rs. 5,000 from current (uses overdraft)", "-3000.0",
                () -> String.valueOf(bank.withdraw(c.getAccountNumber(), 5000)));
        test("T06", "Withdraw beyond overdraft limit (current)", "InsufficientFundsException",
                () -> String.valueOf(bank.withdraw(c.getAccountNumber(), 8000)));
        test("T07", "Deposit a negative amount", "InvalidAmountException",
                () -> String.valueOf(bank.deposit(s.getAccountNumber(), -100)));
        test("T08", "Access a non-existent account", "AccountNotFoundException",
                () -> String.valueOf(bank.checkBalance("ACC9999")));
        test("T09", "Create account with unknown type", "BankException",
                () -> String.valueOf(bank.createAccount("fixed", "X", 100)));
        test("T10", "Polymorphism: same withdraw call, different rule", "Rejected/Success", () -> {
            Account a = new SavingsAccount("T1", "A", 2000);
            Account b = new CurrentAccount("T2", "B", 2000);
            String first, second;
            try { a.withdraw(1800); first = "Success"; } catch (BankException e) { first = "Rejected"; }
            try { b.withdraw(1800); second = "Success"; } catch (BankException e) { second = "Rejected"; }
            return first + "/" + second;
        });
        test("T11", "Abstraction: Account class is abstract", "true",
                () -> String.valueOf(Modifier.isAbstract(Account.class.getModifiers())));
        test("T12", "Encapsulation: balance field is private", "true",
                () -> String.valueOf(Modifier.isPrivate(Account.class.getDeclaredField("balance").getModifiers())));

        PrintWriter out = new PrintWriter(args[0]);
        out.println("id,description,expected,actual,result");
        for (String[] r : rows) {
            out.println(r[0] + ",\"" + r[1] + "\"," + r[2] + "," + r[3] + "," + r[4]);
        }
        out.close();
        int pass = 0;
        for (String[] r : rows) { System.out.println(String.join(" | ", r)); if (r[4].equals("Pass")) pass++; }
        System.out.println(pass + " / " + rows.size() + " tests passed");
    }
}
