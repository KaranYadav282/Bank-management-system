/** Thrown when a withdrawal breaks the rules of the account type. */
public class InsufficientFundsException extends BankException {
    public InsufficientFundsException(String message) {
        super(message);
    }
}
