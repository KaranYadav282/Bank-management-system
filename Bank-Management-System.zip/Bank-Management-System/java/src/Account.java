import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Abstract base class: defines the common data and interface of every account.
 * Demonstrates ENCAPSULATION (private fields) and ABSTRACTION (abstract methods).
 */
public abstract class Account {

    // ---- Encapsulation: all data is private ----
    private final String accountNumber;
    private final String holderName;
    private double balance;
    private final List<Transaction> transactions = new ArrayList<Transaction>();

    protected Account(String accountNumber, String holderName, double openingBalance)
            throws InvalidAmountException {
        if (openingBalance < 0) {
            throw new InvalidAmountException("Opening balance cannot be negative.");
        }
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.balance = openingBalance;
        log("Opening", openingBalance, "Success");
    }

    // ---- Read-only access through getters (no setter for balance) ----
    public String getAccountNumber() { return accountNumber; }
    public String getHolderName()    { return holderName; }
    public double getBalance()       { return balance; }

    public List<Transaction> getTransactions() {
        return Collections.unmodifiableList(transactions);
    }

    // ---- Behaviour shared by all accounts ----
    public double deposit(double amount) throws InvalidAmountException {
        validate(amount);
        balance += amount;
        log("Deposit", amount, "Success");
        return balance;
    }

    // ---- Protected helpers for subclasses ----
    protected double debit(double amount) {
        balance -= amount;
        log("Withdrawal", amount, "Success");
        return balance;
    }

    protected void reject(double amount) {
        log("Withdrawal", amount, "Rejected");
    }

    protected void validate(double amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Amount must be greater than zero.");
        }
    }

    private void log(String type, double amount, String status) {
        transactions.add(new Transaction(type, amount, status, balance));
    }

    // ---- Abstraction: every subclass MUST implement these ----
    public abstract double withdraw(double amount) throws BankException;

    public abstract String getAccountType();

    @Override
    public String toString() {
        return String.format("%-8s | %s | %-22s | Rs. %,12.2f",
                getAccountType(), accountNumber, holderName, balance);
    }
}
