/** Current account: allows withdrawals up to an overdraft limit. */
public class CurrentAccount extends Account {

    private final double overdraftLimit;

    public CurrentAccount(String accountNumber, String holderName, double openingBalance)
            throws InvalidAmountException {
        super(accountNumber, holderName, openingBalance);
        this.overdraftLimit = 10000.0;
    }

    @Override   // Polymorphism: the current-account rule
    public double withdraw(double amount) throws BankException {
        validate(amount);
        if (getBalance() - amount < -overdraftLimit) {
            reject(amount);
            throw new InsufficientFundsException(String.format(
                    "Overdraft limit of Rs. %,.0f exceeded.", overdraftLimit));
        }
        return debit(amount);
    }

    @Override
    public String getAccountType() {
        return "Current";
    }
}
