/** Savings account: earns interest and must keep a minimum balance. */
public class SavingsAccount extends Account {

    private final double interestRate;     // yearly rate, e.g. 0.04 = 4 %
    private final double minimumBalance;

    public SavingsAccount(String accountNumber, String holderName, double openingBalance)
            throws InvalidAmountException {
        super(accountNumber, holderName, openingBalance);
        this.interestRate = 0.04;
        this.minimumBalance = 500.0;
    }

    @Override   // Polymorphism: the savings-account rule
    public double withdraw(double amount) throws BankException {
        validate(amount);
        if (getBalance() - amount < minimumBalance) {
            reject(amount);
            throw new InsufficientFundsException(String.format(
                    "Minimum balance of Rs. %,.0f must be maintained.", minimumBalance));
        }
        return debit(amount);
    }

    /** Credits one month of interest and returns the amount credited. */
    public double addInterest() throws InvalidAmountException {
        double interest = getBalance() * interestRate / 12;
        deposit(interest);
        return interest;
    }

    @Override
    public String getAccountType() {
        return "Savings";
    }
}
