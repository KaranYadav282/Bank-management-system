import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The bank: owns every account and coordinates all operations. */
public class Bank {

    private final String bankName;
    private final Map<String, Account> accounts = new LinkedHashMap<String, Account>();
    private int nextNumber = 1001;

    public Bank(String bankName) {
        this.bankName = bankName;
    }

    public String getBankName() {
        return bankName;
    }

    public Account createAccount(String type, String holderName, double openingBalance)
            throws BankException {
        String number = "ACC" + nextNumber;
        Account account;
        if ("savings".equalsIgnoreCase(type)) {
            account = new SavingsAccount(number, holderName, openingBalance);
        } else if ("current".equalsIgnoreCase(type)) {
            account = new CurrentAccount(number, holderName, openingBalance);
        } else {
            throw new BankException("Account type must be SAVINGS or CURRENT.");
        }
        accounts.put(number, account);
        nextNumber++;
        return account;
    }

    public Account findAccount(String accountNumber) throws AccountNotFoundException {
        Account account = accounts.get(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException("Account " + accountNumber + " not found.");
        }
        return account;
    }

    public double deposit(String accountNumber, double amount) throws BankException {
        return findAccount(accountNumber).deposit(amount);
    }

    public double withdraw(String accountNumber, double amount) throws BankException {
        return findAccount(accountNumber).withdraw(amount);   // polymorphic call
    }

    public double checkBalance(String accountNumber) throws AccountNotFoundException {
        return findAccount(accountNumber).getBalance();
    }

    public List<Account> getAllAccounts() {
        return new ArrayList<Account>(accounts.values());
    }

    public double getTotalBalance() {
        double total = 0;
        for (Account account : accounts.values()) {
            total += account.getBalance();
        }
        return total;
    }
}
