/** Base class for every banking related error (checked exception). */
public class BankException extends Exception {
    public BankException(String message) {
        super(message);
    }
}
