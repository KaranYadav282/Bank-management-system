import java.io.PrintWriter;
import java.util.List;
import java.util.Random;

/** Applies 60 random transactions to 8 accounts and records every result. */
public class Simulation {

    public static void main(String[] args) throws Exception {
        String dir = args[0];
        Bank bank = new Bank("BTech National Bank");
        String[][] people = {
                {"Aarav", "savings", "25000"}, {"Diya", "savings", "18000"}, {"Rohan", "current", "40000"},
                {"Sneha", "savings", "9000"}, {"Kabir", "current", "60000"}, {"Meera", "savings", "32000"},
                {"Vikram", "current", "15000"}, {"Ananya", "savings", "12000"}};
        double[] amounts = {500, 1000, 2000, 3500, 5000, 8000, 12000, 20000, 35000};

        PrintWriter ledger = new PrintWriter(dir + "/ledger.csv");
        PrintWriter running = new PrintWriter(dir + "/running.csv");
        ledger.println("acc,type,kind,amount,status");
        running.println("total");

        for (String[] p : people) {
            Account a = bank.createAccount(p[1], p[0], Double.parseDouble(p[2]));
            ledger.println(a.getAccountNumber() + "," + a.getAccountType() + ",Opening," + p[2] + ",Success");
        }
        running.println(bank.getTotalBalance());

        Random random = new Random(7);
        List<Account> accounts = bank.getAllAccounts();
        for (int i = 0; i < 60; i++) {
            Account acc = accounts.get(random.nextInt(accounts.size()));
            boolean deposit = random.nextInt(3) == 0;           // about one third deposits
            double amount = amounts[random.nextInt(amounts.length)];
            String status = "Success";
            try {
                if (deposit) acc.deposit(amount); else acc.withdraw(amount);
            } catch (BankException e) {
                status = "Rejected";
            }
            ledger.println(acc.getAccountNumber() + "," + acc.getAccountType() + ","
                    + (deposit ? "Deposit" : "Withdrawal") + "," + (int) amount + "," + status);
            running.println(bank.getTotalBalance());
        }
        ledger.close();
        running.close();

        PrintWriter out = new PrintWriter(dir + "/accounts.csv");
        out.println("number,holder,type,balance");
        for (Account a : accounts) {
            out.println(a.getAccountNumber() + "," + a.getHolderName() + "," + a.getAccountType() + "," + a.getBalance());
        }
        out.close();
        System.out.println("Simulation finished. Closing total = " + bank.getTotalBalance());
    }
}
