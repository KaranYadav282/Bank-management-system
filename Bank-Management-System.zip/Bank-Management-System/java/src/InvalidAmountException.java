/** Thrown when an amount is zero, negative or otherwise not acceptable. */
public class InvalidAmountException extends BankException {
    public InvalidAmountException(String message) {
        super(message);
    }
}
