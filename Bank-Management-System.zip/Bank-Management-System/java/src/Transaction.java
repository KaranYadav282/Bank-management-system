import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** One entry in the history of an account. */
public class Transaction {
    private static final DateTimeFormatter FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final String time;
    private final String type;
    private final double amount;
    private final String status;
    private final double balanceAfter;

    public Transaction(String type, double amount, String status, double balanceAfter) {
        this.time = LocalDateTime.now().format(FORMAT);
        this.type = type;
        this.amount = amount;
        this.status = status;
        this.balanceAfter = balanceAfter;
    }

    public String getTime()        { return time; }
    public String getType()        { return type; }
    public double getAmount()      { return amount; }
    public String getStatus()      { return status; }
    public double getBalanceAfter() { return balanceAfter; }
}
