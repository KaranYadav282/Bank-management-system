import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads a CSV file and feeds it to the bank.
 * Expected header: Action,AccountType,HolderName,AccountNumber,Amount
 * Actions: CREATE, DEPOSIT, WITHDRAW, BALANCE
 */
public class CsvProcessor {

    /** Outcome of one CSV row. */
    public static class Result {
        public final int row;
        public final String action;
        public final String account;
        public final String amount;
        public final String status;
        public final String message;

        Result(int row, String action, String account, String amount, String status, String message) {
            this.row = row;
            this.action = action;
            this.account = account;
            this.amount = amount;
            this.status = status;
            this.message = message;
        }
    }

    /** Splits one CSV line; understands "quoted, values". */
    public static String[] parseLine(String line) {
        List<String> fields = new ArrayList<String>();
        StringBuilder current = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (quoted) {
                if (c == '"' && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else if (c == '"') {
                    quoted = false;
                } else {
                    current.append(c);
                }
            } else if (c == '"') {
                quoted = true;
            } else if (c == ',') {
                fields.add(current.toString().trim());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        fields.add(current.toString().trim());
        return fields.toArray(new String[0]);
    }

    /** Reads every line of a CSV file (header included). */
    public static List<String[]> readAll(File file) throws IOException {
        List<String[]> rows = new ArrayList<String[]>();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        try {
            String line;
            boolean first = true;
            while ((line = reader.readLine()) != null) {
                if (first) {                      // remove the BOM written by Excel
                    line = line.replace("\uFEFF", "");
                    first = false;
                }
                if (!line.trim().isEmpty()) {
                    rows.add(parseLine(line));
                }
            }
        } finally {
            reader.close();
        }
        return rows;
    }

    /** Runs every row of the file against the given bank. */
    public static List<Result> process(File file, Bank bank) throws IOException {
        List<String[]> rows = readAll(file);
        List<Result> results = new ArrayList<Result>();
        for (int i = 1; i < rows.size(); i++) {             // row 0 is the header
            String[] f = rows.get(i);
            String action = field(f, 0).toUpperCase();
            String type = field(f, 1);
            String holder = field(f, 2);
            String number = field(f, 3);
            String amountText = field(f, 4);
            try {
                switch (action) {
                    case "CREATE": {
                        Account a = bank.createAccount(type, holder, Double.parseDouble(amountText));
                        results.add(new Result(i, action, a.getAccountNumber(), amountText, "Success",
                                "Created " + a.getAccountType() + " account for " + holder));
                        break;
                    }
                    case "DEPOSIT": {
                        double bal = bank.deposit(number, Double.parseDouble(amountText));
                        results.add(new Result(i, action, number, amountText, "Success",
                                String.format("New balance Rs. %,.2f", bal)));
                        break;
                    }
                    case "WITHDRAW": {
                        double bal = bank.withdraw(number, Double.parseDouble(amountText));
                        results.add(new Result(i, action, number, amountText, "Success",
                                String.format("New balance Rs. %,.2f", bal)));
                        break;
                    }
                    case "BALANCE": {
                        double bal = bank.checkBalance(number);
                        results.add(new Result(i, action, number, "-", "Success",
                                String.format("Balance is Rs. %,.2f", bal)));
                        break;
                    }
                    default:
                        results.add(new Result(i, action, number, amountText, "Rejected",
                                "Unknown action"));
                }
            } catch (NumberFormatException e) {
                results.add(new Result(i, action, number, amountText, "Rejected", "Amount is not a number"));
            } catch (BankException e) {
                results.add(new Result(i, action, number, amountText, "Rejected", e.getMessage()));
            }
        }
        return results;
    }

    private static String field(String[] f, int index) {
        return index < f.length ? f[index] : "";
    }
}
