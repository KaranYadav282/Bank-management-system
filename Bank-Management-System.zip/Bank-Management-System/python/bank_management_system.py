"""
Bank Management System - Python version
Sri Sri University | Second Year BTech Project

Demonstrates the four pillars of OOP:
    Encapsulation, Inheritance, Polymorphism and Abstraction.

Classes : Account (abstract), SavingsAccount, CurrentAccount, Bank
Features: create accounts, deposit, withdraw, check balance, import a CSV file

How to run
    python bank_management_system.py                      -> interactive menu
    python bank_management_system.py data.csv             -> process a transactions CSV file
    python bank_management_system.py data.csv -o out.csv  -> ... and save the results

CSV columns: Action, AccountType, HolderName, AccountNumber, Amount
Actions    : CREATE, DEPOSIT, WITHDRAW, BALANCE
"""

import csv
import sys
from abc import ABC, abstractmethod


# --------------------------------------------------------------------------
# Exceptions
# --------------------------------------------------------------------------
class BankError(Exception):
    """Base class for every banking related error."""


class InvalidAmountError(BankError):
    """Raised when an amount is zero, negative or otherwise not acceptable."""


class InsufficientFundsError(BankError):
    """Raised when a withdrawal breaks the rules of the account type."""


class AccountNotFoundError(BankError):
    """Raised when an account number does not exist in the bank."""


# --------------------------------------------------------------------------
# Object model
# --------------------------------------------------------------------------
class Account(ABC):
    """Abstract base class: common data and interface of every account."""

    def __init__(self, account_number, holder_name, opening_balance=0.0):
        if opening_balance < 0:
            raise InvalidAmountError("Opening balance cannot be negative.")
        self.__account_number = account_number      # private (Encapsulation)
        self.__holder_name = holder_name            # private
        self.__balance = float(opening_balance)     # private
        self._transactions = []                     # protected by convention
        self._log("Opening", opening_balance, "Success")

    # ---- read-only access through properties (no setter for balance) ----
    @property
    def account_number(self):
        return self.__account_number

    @property
    def holder_name(self):
        return self.__holder_name

    @property
    def balance(self):
        return self.__balance

    @property
    def transactions(self):
        return list(self._transactions)             # a copy keeps the original safe

    # ---- behaviour shared by all accounts ----
    def deposit(self, amount):
        self._validate(amount)
        self.__balance += amount
        self._log("Deposit", amount, "Success")
        return self.__balance

    # ---- protected helpers for subclasses ----
    def _debit(self, amount):
        self.__balance -= amount
        self._log("Withdrawal", amount, "Success")
        return self.__balance

    def _reject(self, amount):
        self._log("Withdrawal", amount, "Rejected")

    @staticmethod
    def _validate(amount):
        if amount <= 0:
            raise InvalidAmountError("Amount must be greater than zero.")

    def _log(self, kind, amount, status):
        self._transactions.append({"type": kind, "amount": float(amount),
                                   "status": status, "balance_after": self.__balance})

    # ---- Abstraction: every subclass MUST implement these ----
    @abstractmethod
    def withdraw(self, amount):
        """Each account type applies its own withdrawal rule."""

    @abstractmethod
    def account_type(self):
        """Return the name of the account type."""

    def __str__(self):
        return (f"{self.account_type():<8} | {self.account_number} | "
                f"{self.holder_name:<22} | Rs. {self.balance:>12,.2f}")


class SavingsAccount(Account):
    """Earns interest and must always keep a minimum balance."""

    def __init__(self, account_number, holder_name, opening_balance=0.0):
        super().__init__(account_number, holder_name, opening_balance)
        self.interest_rate = 0.04
        self.minimum_balance = 500.0

    def withdraw(self, amount):                     # Polymorphism: savings rule
        self._validate(amount)
        if self.balance - amount < self.minimum_balance:
            self._reject(amount)
            raise InsufficientFundsError(
                f"Minimum balance of Rs. {self.minimum_balance:,.0f} must be maintained.")
        return self._debit(amount)

    def add_interest(self):
        """Credits one month of interest and returns the amount credited."""
        interest = self.balance * self.interest_rate / 12
        self.deposit(interest)
        return interest

    def account_type(self):
        return "Savings"


class CurrentAccount(Account):
    """Business account that allows withdrawals up to an overdraft limit."""

    def __init__(self, account_number, holder_name, opening_balance=0.0):
        super().__init__(account_number, holder_name, opening_balance)
        self.overdraft_limit = 10000.0

    def withdraw(self, amount):                     # Polymorphism: current-account rule
        self._validate(amount)
        if self.balance - amount < -self.overdraft_limit:
            self._reject(amount)
            raise InsufficientFundsError(
                f"Overdraft limit of Rs. {self.overdraft_limit:,.0f} exceeded.")
        return self._debit(amount)

    def account_type(self):
        return "Current"


class Bank:
    """The bank: owns every account and coordinates all operations."""

    def __init__(self, name):
        self.name = name
        self.__accounts = {}                        # private storage
        self.__next_number = 1001

    def create_account(self, kind, holder_name, opening_balance=0.0):
        number = f"ACC{self.__next_number}"
        kind = kind.strip().lower()
        if kind == "savings":
            account = SavingsAccount(number, holder_name, opening_balance)
        elif kind == "current":
            account = CurrentAccount(number, holder_name, opening_balance)
        else:
            raise BankError("Account type must be SAVINGS or CURRENT.")
        self.__accounts[number] = account
        self.__next_number += 1
        return account

    def find_account(self, account_number):
        try:
            return self.__accounts[account_number]
        except KeyError:
            raise AccountNotFoundError(f"Account {account_number} not found.")

    def deposit(self, account_number, amount):
        return self.find_account(account_number).deposit(amount)

    def withdraw(self, account_number, amount):
        return self.find_account(account_number).withdraw(amount)   # polymorphic call

    def check_balance(self, account_number):
        return self.find_account(account_number).balance

    def all_accounts(self):
        return list(self.__accounts.values())

    def total_balance(self):
        return sum(a.balance for a in self.__accounts.values())


# --------------------------------------------------------------------------
# CSV import
# --------------------------------------------------------------------------
REQUIRED_COLUMNS = ["Action", "AccountType", "HolderName", "AccountNumber", "Amount"]


def process_csv(path, bank):
    """Runs every row of a transactions CSV file against the bank.

    Returns a list of dictionaries: row, action, account, amount, status, message.
    """
    with open(path, newline="", encoding="utf-8-sig") as handle:
        rows = [r for r in csv.reader(handle) if any(f.strip() for f in r)]
    if not rows:
        raise BankError("The file is empty.")
    header = [h.strip().lower() for h in rows[0]]
    index = {name: (header.index(name.lower()) if name.lower() in header else -1)
             for name in REQUIRED_COLUMNS}
    if index["Action"] < 0 or index["Amount"] < 0:
        raise BankError("This does not look like a transactions file. The first row must "
                        "contain the columns: " + ", ".join(REQUIRED_COLUMNS) + ".")

    def field(row, name):
        i = index[name]
        return row[i].strip() if 0 <= i < len(row) else ""

    results = []
    for number_of_row, row in enumerate(rows[1:], start=1):
        action = field(row, "Action").upper()
        kind, holder = field(row, "AccountType"), field(row, "HolderName")
        number, amount_text = field(row, "AccountNumber"), field(row, "Amount")

        def add(account, amount, status, message):
            results.append({"row": number_of_row, "action": action, "account": account,
                            "amount": amount, "status": status, "message": message})
        try:
            if action in ("CREATE", "DEPOSIT", "WITHDRAW"):
                try:
                    amount = float(amount_text)
                except ValueError:
                    raise BankError("Amount is not a number")
            if action == "CREATE":
                account = bank.create_account(kind, holder, amount)
                add(account.account_number, amount_text, "Success",
                    f"Created {account.account_type()} account for {holder}")
            elif action == "DEPOSIT":
                add(number, amount_text, "Success", f"New balance Rs. {bank.deposit(number, amount):,.2f}")
            elif action == "WITHDRAW":
                add(number, amount_text, "Success", f"New balance Rs. {bank.withdraw(number, amount):,.2f}")
            elif action == "BALANCE":
                add(number, "-", "Success", f"Balance is Rs. {bank.check_balance(number):,.2f}")
            else:
                add(number, amount_text, "Rejected", "Unknown action")
        except BankError as error:
            add(number, amount_text, "Rejected", str(error))
    return results


def print_results(results, bank):
    print(f"{'#':>3}  {'Action':<9} {'Account':<9} {'Amount':>9}  {'Status':<9} Details")
    print("-" * 86)
    for r in results:
        print(f"{r['row']:>3}  {r['action']:<9} {r['account']:<9} {r['amount']:>9}  {r['status']:<9} {r['message']}")
    ok = sum(r["status"] == "Success" for r in results)
    print("-" * 86)
    print(f"Rows processed: {len(results)} | Successful: {ok} | Rejected: {len(results) - ok} | "
          f"Total balance now: Rs. {bank.total_balance():,.2f}")


def save_results(results, path):
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Row", "Action", "Account", "Amount", "Status", "Details"])
        for r in results:
            writer.writerow([r["row"], r["action"], r["account"], r["amount"], r["status"], r["message"]])


# --------------------------------------------------------------------------
# Console menu
# --------------------------------------------------------------------------
def menu(bank):
    text = ("\n=== BTech National Bank ===\n1. Create account\n2. Deposit\n3. Withdraw\n"
            "4. Check balance\n5. List accounts\n6. Import CSV file\n7. Exit\n")
    while True:
        print(text)
        choice = input("Choose an option (1-7): ").strip()
        try:
            if choice == "1":
                kind = input("Type (savings/current): ")
                name = input("Account holder name: ")
                account = bank.create_account(kind, name, float(input("Opening balance (Rs.): ")))
                print(f"Account created -> {account.account_number}")
            elif choice == "2":
                number = input("Account number: ")
                print(f"Deposit successful. New balance: Rs. {bank.deposit(number, float(input('Amount (Rs.): '))):,.2f}")
            elif choice == "3":
                number = input("Account number: ")
                print(f"Withdrawal successful. New balance: Rs. {bank.withdraw(number, float(input('Amount (Rs.): '))):,.2f}")
            elif choice == "4":
                print(f"Balance: Rs. {bank.check_balance(input('Account number: ')):,.2f}")
            elif choice == "5":
                for account in bank.all_accounts():
                    print(account)
            elif choice == "6":
                print_results(process_csv(input("Path of the CSV file: ").strip(), bank), bank)
            elif choice == "7":
                print("Thank you for banking with us.")
                break
            else:
                print("Invalid option. Please choose between 1 and 7.")
        except ValueError:
            print("Error: please enter a valid number.")
        except (BankError, OSError) as error:
            print(f"Error: {error}")


def main(argv):
    bank = Bank("BTech National Bank")
    if len(argv) >= 2:
        try:
            results = process_csv(argv[1], bank)
        except (BankError, OSError) as error:
            print(f"Error: {error}")
            return 1
        print_results(results, bank)
        if "-o" in argv and argv.index("-o") + 1 < len(argv):
            save_results(results, argv[argv.index("-o") + 1])
            print(f"Results saved to {argv[argv.index('-o') + 1]}")
        return 0
    menu(bank)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
